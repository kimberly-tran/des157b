(function() {
    'use strict';
    console.log('js running');

    //usability test alert
    // alert("Imagine you are a fourth-grade elementary student at North Davis Elementary School. You’ve just started a new lesson in class on the history of Davis, and your teacher instructs you and your classmates to learn more about the Arboretum by playing this online desktop game. Try navigating the game and to learn more about the Arboretum.");

    //setting up different pages/overlays
    const galleryBtn = document.getElementById('galleryBtn');
    const instructionBtn = document.getElementById('instructionBtn');
    const gallery = document.querySelector('#gallery');
    let description = document.querySelector('#description');
    const instructions = document.querySelector('#instructions');
    const closeBtns = document.querySelectorAll('.close');
    const gameArea = document.querySelector('#gameArea');
    const popup = document.querySelector('#popup');
    let arbInstructions = false;


    //opening/closing gallery + instructions
    galleryBtn.addEventListener('click', function() {
        gallery.className = 'showing';
        instructions.className = 'hidden';
        gameArea.className = 'hidden';
        popup.className = 'hidden';
    })

    instructionBtn.addEventListener('click', function() {
        instructions.className = 'showing';
        // gallery.className = 'hidden';
        // gameArea.className = 'hidden';
        popup.className = 'hidden';

        if (arbInstructions == false) {
            document.querySelector("#instructions h3").innerHTML = "Navigate to a part of the seal using the arrow keys and click “start” to play."
        }
        if (arbInstructions == true) {
            document.querySelector("#instructions h3").innerHTML = "Press “spacebar” to jump. Avoid the different items and creatures coming your way!"
        }
    })

    closeBtns.forEach((closeBtn) => {
        closeBtn.addEventListener('click', function() {
            gallery.className = 'hidden';
            instructions.className = 'hidden';
            gameArea.className = 'showing';
            gameArea.focus();
        });
    });


    //gathering data for gallery
    async function getData() {
        const arboretum = await fetch('data/arboretum.json');
        const data = await arboretum.json();
        console.log(data);
        document.querySelector('.container').innerHTML = outputGallery(data);
        document.querySelector('#description').innerHTML = createDescriptions(data);

        // createDescriptions();
    }

    let galleryContainer = document.querySelector('.container');

    function outputGallery(data) {
        const dataPoints = Object.keys(data);
        // console.log(dataPoints);
        let galleryContainer = "";

        for (let i = 0; i < dataPoints.length; i++) {
            let newItem = document.createElement("div");

            let html = `<div class="item" id="${data[dataPoints[i]].id}">`;
            html += `<img src="images/${data[dataPoints[i]].image}" alt="${data[dataPoints[i]].name}" width="120">
            <h3>${data[dataPoints[i]].name}</h3>`;
            html += '</div>';
            newItem = html;
            galleryContainer += newItem;
            
            // console.log(newItem)
           
        }
        return galleryContainer;
    }

    getData();


    function createDescriptions(data) {
        const items = document.querySelectorAll('.item');
        console.log(items)

        for (const item of items) {
            item.addEventListener('click', function(event) {

                // alert("Sorry, still under construction! A description about what you clicked on should pop up.");

                const itemID = event.target.id;
                console.log(itemID)
                console.log(data[itemID])
                
                description.innerHTML = `
                    <article>
                        <img src="images/${data[itemID].image}" alt="${data[itemID].name}" width="120">
                        <h3>${data[itemID].name}</h3>
                        <p>${data[itemID].description}</p>
                        <div id="closeDescription" class="close button">close</div>
                    </article>`

                document.querySelector('#closeDescription').addEventListener('click', function() {
                    description.className = "hidden";
                });
                // document.querySelector('#description h3').innerHTML = data[itemID].name;
                // document.querySelector('#description p').innerHTML = data[itemID].description;

                console.log(description)
                description.className = "showing"

            });
        }
    }

    //kaboom seal map
    const map = kaboom({
        global: false,
        canvas: document.querySelector('#gameArea'),
    })
    
    map.loadSprite("boyDown", "images/boyDown.png")
    map.loadSprite("boyUp", "images/boyUp.png")
    map.loadSprite("boyRight", "images/boyRight.png")    
    map.loadSprite("boyLeft", "images/boyLeft.png")    
    map.loadSprite("tempbg", "images/background.png")
    map.loadSprite("temparea", "images/featherR.png")
    map.loadSprite("temparea2", "images/pigsqueak.png")
    map.loadSprite("temparea3", "images/turtle1.png")
    map.loadSprite("butterfly", "images/monarch1.png",{
        sliceX: 2,
        anims: {
            "fly": {
                from: 0,
                to: 1,
                speed: 8,
                loop: true,
            }
        }
    })

    
    // for me: create a new one for front, side etc. -> player = boyfront onKeyDown
    map.add([
        map.sprite("tempbg"),
        // tempbg.scale(2)
    ])

    const tempCollisionArea = map.add([
        map.sprite("temparea"),
        map.scale(2),
        map.pos(490, 95),
        map.area(),
        "tempCollisionArea"
    ])

    const tempCollisionArea2 = map.add([
        map.sprite("temparea2"),
        map.scale(2),
        map.pos(450, 100),
        map.area(),
        "tempCollisionArea"
    ])

    const tempCollisionArea3 = map.add([
        map.sprite("temparea3"),
        map.scale(1),
        map.pos(480, 100),
        map.area(),
        "tempCollisionArea"
    ])

    const tempCollisionArea4 = map.add([
            map.sprite("butterfly"),
            map.scale(1),
            map.pos(500, 80),
            map.area(),
            "butterfly",
    ])
    tempCollisionArea4.play("fly");


    let boy = map.add([
        map.sprite("boyDown"),
        map.pos(470, 250),
        map.area(),
    ])

    let player = boy;
    const SPEED = 120

    map.onKeyDown("left", () => {
        player.use(map.sprite('boyLeft'))
        player.move(-SPEED, 0)
    })

    map.onKeyDown("right", () => {
        player.use(map.sprite('boyRight'))
        player.move(SPEED, 0)
    })

    map.onKeyDown("up", () => {
        player.move(0, -SPEED),
        player.use(map.sprite('boyUp'))
    })

    map.onKeyDown("down", () => {
        // boy = map.readd([
        //     map.sprite("boyDown"),
        //     map.area(),
        // ])
        player.move(0, SPEED),
        player.use(map.sprite('boyDown'))
    })
    
    player.onCollide("tempCollisionArea", (tempCollisionArea) => {
        popup.className = 'showing';
    })

    player.onCollideEnd("tempCollisionArea", (tempCollisionArea) => {
        popup.className = 'hidden';
    })

    //connecting levels to map
    const arboretumStart = document.querySelector('#arboretum');

    arboretumStart.addEventListener('click', function() {
        arboretumLevel();
        arbInstructions = true;
    });



    //kaboom jumping levels
   function arboretumLevel() {
        popup.className = 'hidden';

        const arb = kaboom({
            global: false,
            canvas: document.querySelector('#gameArea'),
            scale: 2,
    })

    const FLOOR_HEIGHT = 48
    const JUMP_FORCE = 800
    const SPEED2 = 300

    arb.setBackground(141, 183, 255)

    // load assets
    arb.loadSprite("bean", "images/boy.png", {
        sliceX: 6,
        anims: {
            "run": {
                from: 1,
                to: 4,
                speed: 10,
                loop: true,
            },

            "jump1": 5,
        }
    })
    arb.loadSprite("tree", "images/mexicanT.png")
    arb.loadSprite("bird", "images/cormorant1.png",{
        sliceX: 2,
        anims: {
            "fly": {
                from: 0,
                to: 1,
                speed: 3,
                loop: true,
            }
        }
    })
    arb.loadSprite("butterfly", "images/monarch1.png",{
        sliceX: 2,
        anims: {
            "fly": {
                from: 0,
                to: 1,
                speed: 8,
                loop: true,
            }
        }
    })
    arb.scene("game", () => {

	// define gravity
        arb.setGravity(2600)

        // add a game object to screen
        const player = arb.add([
            // list of components
            arb.sprite("bean"),
            arb.pos(80, 40),
            arb.anchor("center"),
            arb.area(),
            arb.body(),
        ])

        player.play("run")
        // player.onAnimEnd((anim) =>{
        //     if(anim === "run"){

        //     }
        // })

        player.onGround(() => {
            player.play("run")
        })

        // floor
        arb.add([
            arb.rect(arb.width(), FLOOR_HEIGHT),
            arb.outline(4),
            arb.pos(0, arb.height()),
            arb.anchor("botleft"),
            arb.area(),
            arb.body({ isStatic: true }),
            arb.color(50, 156, 50),
        ])

        function jump() {
            if (player.isGrounded()) {
                player.jump(JUMP_FORCE)
                player.play("jump1")
            }
        }

        // jump when user press space
        arb.onKeyPress("space", jump)
        arb.onClick(jump)

        function spawnTree() {

            // add tree obj
            arb.add([
                arb.sprite("tree"),
                arb.area({ scale: 0.3 }),
                arb.scale(2),
                // rect(48, rand(32, 96)),
                // area(),
                arb.outline(4),
                arb.pos(arb.width(), arb.height() - FLOOR_HEIGHT),
                arb.anchor("botleft"),
                arb.color(238, 143, 203),
                arb.move(arb.vec2(-1, 0), SPEED2),
                arb.offscreen({ destroy: true }),
                "tree",
            ])

            // wait a random amount of time to spawn next tree
            arb.wait(arb.rand(1, 4), spawnTree)

        }

            // lose if player collides with any game obj with tag "tree"
            player.onCollide("tree",() => {
                // go to "lose" scene and pass the score
                arb.go("lose", score)
                arb.addKaboom(player.pos)
            })
        // start spawning trees
        spawnTree()

        setTimeout(() => {
            function spawnButterfly() {

                // add insect obj
                // arb.add([
                //     arb.sprite("butterfly"),
                //     arb.area({ scale: 0.1 }),
                //     arb.scale(1),
                // 	// rect(48, rand(32, 96)),
                // 	// area(),
                // 	arb.outline(4),
                // 	arb.pos(arb.width(), arb.height() - FLOOR_HEIGHT),
                // 	arb.anchor("botleft"),
                // 	arb.color(238, 143, 203),
                // 	arb.move(arb.vec2(-1, 0), SPEED2),
                // 	arb.offscreen({ destroy: true }),
                // 	"butterfly",
                // ])

                const butterfly = arb.add([
                    arb.sprite("butterfly"),
                    arb.area({scale: 0.6}),
                    arb.outline(4),
                    arb.pos(arb.width(), arb.rand(250, 280) - FLOOR_HEIGHT),
                    arb.anchor("botleft"),
                    arb.color(238, 143, 203),
                    arb.move(arb.vec2(-1, 0), SPEED2),
                    arb.offscreen({ destroy: true }),
                    "butterfly",
                ]);

                butterfly.play("fly"),
                    // lose if player collides with any game obj with tag "tree"

                // wait a random amount of time to spawn next tree
                arb.wait((3, 5), spawnButterfly)

            }

            // start spawning trees
            spawnButterfly()

        }, 4000);

        player.onCollide("butterfly",() => {
            // go to "lose" scene and pass the score
            arb.go("lose2", score)
            arb.addKaboom(player.pos)
        })


        function spawnBird() {
            console.log("bird spawned")

            // add bird obj
            // arb.add([
            //     arb.sprite("bird"),
            //     arb.scale(1),
            // 	// rect(48, rand(32, 96)),
            // 	arb.area(),
            // 	arb.outline(4),
            // 	arb.pos(arb.width(), 300 - FLOOR_HEIGHT),
            //     // pos(width(), height(10)),
            // 	arb.anchor("botleft"),
            // 	arb.color(238, 143, 203),
            // 	arb.move(arb.vec2(-1, 0), SPEED2),
            // 	arb.offscreen({ destroy: true }),
            // 	"bird",
            // ])

            const bird = arb.add([
                arb.sprite("bird"),
                arb.area({scale: 0.8}),
                arb.outline(4),
                arb.pos(arb.width(), arb.rand(200, 280) - FLOOR_HEIGHT),
                arb.anchor("botleft"),
                arb.color(238, 143, 203),
                arb.move(arb.vec2(-1, 0), SPEED2),
                arb.offscreen({ destroy: true }),
                "bird",
            ]);

            bird.play("fly"),

            // wait a random amount of time to spawn next bird
            arb.wait((2, 6), spawnBird)


        }
        
        // start spawning birds
        setTimeout(spawnBird, 2000);
        

        // lose if player collides with any game obj with tag "bird"
        player.onCollide("bird", () => {
            // go to "lose2" scene and pass the score
            arb.go("lose3", score)
            arb.addKaboom(player.pos)
        })






        // keep track of score
        let score = 0

        const scoreLabel = arb.add([
            arb.text(score),
            arb.pos(24, 24),
        ])

        // increment score every frame
        arb.onUpdate(() => {
            score++
            scoreLabel.text = score
        })

        // if (score > 200) {
        // 	const SPEED = add([
        // 		1000
        // 	])
        // }

    })

    arb.scene("lose", (score) => {

        arb.add([
            arb.sprite("tree"),
            arb.pos(arb.width() / 2, arb.height() / 2 - 64),
            arb.scale(4),
            arb.anchor("center"),
        ])

        // display score
        arb.add([
            arb.text(score),
            arb.pos(arb.width() / 2, arb.height() / 2 + 64),
            arb.scale(2),
            arb.anchor("center"),
        ])

        // go back to game with space is pressed
        arb.onKeyPress("space", () => arb.go("game"))
        arb.onClick(() => arb.go("game"))

    })

    arb.scene("lose2", (score) => {

        arb.add([
            arb.sprite("butterfly"),
            arb.pos(arb.width() / 2, arb.height() / 2 - 64),
            arb.scale(2.5),
            arb.anchor("center"),
        ])


        // display score
        arb.add([
            arb.text(score),
            arb.pos(arb.width() / 2, arb.height() / 2 + 64),
            arb.scale(2),
            arb.anchor("center"),
        ])

        // go back to game with space is pressed
        arb.onKeyPress("space", () => arb.go("game"))
        arb.onClick(() => arb.go("game"))

    })

    arb.scene("lose3", (score) => {

        arb.add([
            arb.sprite("bird"),
            arb.pos(arb.width() / 2, arb.height() / 2 - 64),
            arb.scale(3),
            arb.anchor("center"),
        ])

        // display score
        arb.add([
            arb.text(score),
            arb.pos(arb.width() / 2, arb.height() / 2 + 64),
            arb.scale(2),
            arb.anchor("center"),
        ])



        // go back to game with space is pressed
        arb.onKeyPress("space", () => arb.go("game"))
        arb.onClick(() => arb.go("game"))

    })
    arb.go("game")

}

})();