const playButton = document.querySelector('#play');
const closeButton = document.querySelector('.fa-xmark');
const overlay = document.querySelector('#overlay');

playButton.addEventListener('click', function() {
    overlay.className = "showing";
});

closeButton.addEventListener('click', function() {
    overlay.className = "hidden";
});

function setup() {
    let canvas = createCanvas(600, 400);
    canvas.parent('canvasContainer');
}

function draw() {
    if (mouseIsPressed) {
        stroke(0);
        strokeWeight(5); 
        smooth();
    }
    else {
        noStroke();
    }
    ellipse(mouseX, mouseY, 1, 1);
}